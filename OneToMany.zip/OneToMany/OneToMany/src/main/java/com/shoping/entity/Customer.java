package com.shoping.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Customer {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cid;
	
	private String cname;
	
	@OneToMany(mappedBy = "cust",cascade=CascadeType.ALL)
	private List<Product>p1;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public List<Product> getP1() {
		return p1;
	}

	public void setP1(List<Product> p1) {
		this.p1 = p1;
	}
}
