package com.shoping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.shoping.entity.Customer;
import com.shoping.entity.Product;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
    	SessionFactory factory=new Configuration().configure().buildSessionFactory();
        Session session=factory.openSession();
        
        Transaction tx=session.beginTransaction();
        
      
        
 
    Customer c=new Customer();
        
        c.setCname("Sam");
        Product p1=new Product("kurta",1500,c);
        Product p2=new Product("bag",1500,c);
        Product p3=new Product("Laptop",15000,c);
        Product p4=new Product("Lipstic",1500,c);
        List<Product>p=new ArrayList<Product>();
        p.add(p1);
        p.add(p2);
        p.add(p3);
        p.add(p4);
        c.setP1(p);
        session.save(c);
        tx.commit();
        session.close();
        System.out.println("Done");
    }
}
