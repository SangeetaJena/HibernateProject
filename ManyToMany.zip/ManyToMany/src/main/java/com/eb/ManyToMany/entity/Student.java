package com.eb.ManyToMany.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name="students")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int sid;

	private String sname;

	private int age;
	
	@ManyToMany
	@JoinTable(
			name="stud_course",
	joinColumns=@JoinColumn(name="sid"),

inverseJoinColumns=@JoinColumn(name="cid"))
	
	private Set<Course>c=new HashSet<>();

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String sname, int age) {
		super();
		this.sname = sname;
		this.age = age;
		
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Set<Course> getC() {
		return c;
	}

	public void setC(Set<Course> c) {
		this.c = c;
	}
}
