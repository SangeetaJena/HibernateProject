package com.eb.ManyToMany;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.eb.ManyToMany.entity.Course;
import com.eb.ManyToMany.entity.Student;
public class App 
{
    public static void main( String[] args )
    {
    	SessionFactory factory=new Configuration().configure().buildSessionFactory();
        Session session=factory.openSession();
        
        Transaction tx=session.beginTransaction();
        
        Course c1=new Course("Java Full Stack",2000);
        Course c2=new Course("Pythonb",5000);
        
        Student s1=new Student("sam",22);
        Student s2=new Student("jhon",23);
        s1.getC().add(c1);
        s1.getC().add(c2);
        s2.getC().add(c2);
        session.save(s1);
        session.save(s2);
        session.save(c1);
        session.save(c2);
        tx.commit();
        session.close();
        System.out.println("Data stored");
    }
}
