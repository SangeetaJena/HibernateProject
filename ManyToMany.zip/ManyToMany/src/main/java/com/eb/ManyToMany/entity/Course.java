package com.eb.ManyToMany.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name="courses")
public class Course {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cid;
private String cname;

private int fees;
@ManyToMany(mappedBy="c")
private Set<Student>stud=new HashSet<>();
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Set<Student> getStud() {
		return stud;
	}

	public void setStud(Set<Student> stud) {
		this.stud = stud;
	}

	public Course(String cname, int fees) {
		super();
		this.cname = cname;
		this.fees = fees;
		
	}

	
}
